#/bash/sh
scp vm_eraser_detect root@10.0.5.5:/root/chenmeng/
