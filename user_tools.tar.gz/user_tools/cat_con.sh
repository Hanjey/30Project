#/bin/sh
 cat ~/temp/first.txt 
 cat /dev/null > ~/temp/first.txt
