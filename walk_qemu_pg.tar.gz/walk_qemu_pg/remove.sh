#/bash/sh
rmmod DetectMemory
