#/bash/sh
rmmod walk_process
