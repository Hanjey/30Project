#/bash/sh
insmod DetectMemory.ko
