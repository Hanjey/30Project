#/bash/sh
insmod walk_process.ko
